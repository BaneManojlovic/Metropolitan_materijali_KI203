/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ilove
 */
public class Zadatak1 {
   // Zadatak 1 Napraviti program koji pretvara kilograme u grame od 1 do 200. Koristiti for petlju. 
    public static void main(String[] args) {
       
        
        for(int i=1; i<=200; i++){
            System.out.println("Vrednost kilograma u gramima je: "+i*1000);
        }
    }
}
