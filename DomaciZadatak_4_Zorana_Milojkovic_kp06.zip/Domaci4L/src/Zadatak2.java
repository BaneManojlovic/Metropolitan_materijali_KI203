/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ilove
 */
public class Zadatak2 {
   // Zadatak 2 Napraviti program koji računa površinu kvadrata za sve stranice a od 20 do 1000 koristeći while petlju 
     public static void main(String[] args) {
         int a;
         a = 20;
         while (a<1000){
             System.out.println(a*a);
             a++ ;
         }
   
     }
}
