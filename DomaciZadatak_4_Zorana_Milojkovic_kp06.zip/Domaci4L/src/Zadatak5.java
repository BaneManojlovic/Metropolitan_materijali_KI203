/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Ilove
 */
public class Zadatak5 {
    //Zadatak 5 Napisati program koji će pomoću while petlje odrediti najmanji broj n čiji je stepen n2 veći od 12000.
     public static void main(String[] args) {
 
            int n = 1;
            
            while (n*n <= 12000) {
                
                   n++;
  }
 
  System.out.println("Najmanji broj n čiji je stepen n^2 veći od 12000 je: " + n);
 
 
 }
}
    

